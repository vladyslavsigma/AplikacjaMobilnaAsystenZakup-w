// app/(tabs)/map.tsx
import React, { useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    ActivityIndicator,
    Alert,
    Platform,
    Linking,
    Dimensions, ScrollView
} from 'react-native';
import MapView, { Marker, Circle, PROVIDER_DEFAULT, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import Icon from 'react-native-vector-icons/MaterialIcons';

const { width, height } = Dimensions.get('window');


import Config from '../constants/Config';
const API_BASE_URL = Config.API_BASE_URL;


interface Store {
    id: string;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
    rating?: number;
    phoneNumber?: string;
    distanceFromUser?: number;
    formattedDistance?: string;
}

export default function MapScreen() {
    const [loading, setLoading] = useState(true);
    const [locationLoading, setLocationLoading] = useState(true);
    const [radius, setRadius] = useState(5); // km
    const [userLocation, setUserLocation] = useState<Region | null>(null);
    const [stores, setStores] = useState<Store[]>([]);
    const [selectedStore, setSelectedStore] = useState<Store | null>(null);
    const mapRef = useRef<MapView>(null);

    const defaultRegion: Region = {
        latitude: 51.7592,
        longitude: 19.4559,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
    };

    useEffect(() => {
        getUserLocation();
    }, []);

    useEffect(() => {
        if (userLocation) {
            fetchStores();
        }
    }, [userLocation, radius]);

    const getUserLocation = async () => {
        try {
            setLocationLoading(true);

            // Poproś o uprawnienia
            let { status } = await Location.requestForegroundPermissionsAsync();

            if (status !== 'granted') {
                Alert.alert(
                    'Uprawnienia do lokalizacji',
                    'Aplikacja wymaga dostępu do lokalizacji.',
                    [
                        {
                            text: 'OK',
                            onPress: () => {
                                setUserLocation(defaultRegion);
                                moveCameraToLocation(defaultRegion);
                            }
                        }
                    ]
                );
                return;
            }

            const location = await Location.getCurrentPositionAsync({
                accuracy: Location.Accuracy.Balanced,
            });

            const region: Region = {
                latitude: location.coords.latitude,
                longitude: location.coords.longitude,
                latitudeDelta: 0.05,
                longitudeDelta: 0.05,
            };

            setUserLocation(region);
            moveCameraToLocation(region);

        } catch (error) {
            console.error('Błąd lokalizacji:', error);
            setUserLocation(defaultRegion);
            moveCameraToLocation(defaultRegion);
        } finally {
            setLocationLoading(false);
        }
    };

    const moveCameraToLocation = (region: Region) => {
        if (mapRef.current) {
            mapRef.current.animateToRegion(region, 1000);
        }
    };

    const fetchStores = async () => {
        if (!userLocation) return;

        try {
            setLoading(true);

            const response = await fetch(`${API_BASE_URL}/maps/stores/in-radius`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    latitude: userLocation.latitude,
                    longitude: userLocation.longitude,
                    radiusKm: radius,
                }),
            });

            if (response.ok) {
                const data = await response.json();
                if (data.stores) {
                    setStores(data.stores);
                } else {
                    setStores(getSampleStores());
                }
            } else {
                setStores(getSampleStores());
            }

        } catch (error) {
            console.error('Błąd:', error);
            setStores(getSampleStores());
        } finally {
            setLoading(false);
        }
    };

    const getSampleStores = (): Store[] => {
        if (!userLocation) return [];

        const sampleStores: Store[] = [
            {
                id: '1',
                name: 'Biedronka',
                address: 'ul. Piotrkowska 193, Łódź',
                latitude: userLocation.latitude + 0.005,
                longitude: userLocation.longitude + 0.005,
                rating: 4.2,
                phoneNumber: '+48 42 630 15 67',
                distanceFromUser: 1.2,
                formattedDistance: '1.2 km'
            },
            {
                id: '2',
                name: 'Lidl',
                address: 'ul. Pabianicka 245, Łódź',
                latitude: userLocation.latitude - 0.003,
                longitude: userLocation.longitude + 0.008,
                rating: 4.4,
                phoneNumber: '+48 42 675 43 21',
                distanceFromUser: 3.5,
                formattedDistance: '3.5 km'
            },
            {
                id: '3',
                name: 'Carrefour',
                address: 'al. Piłsudskiego 22, Łódź',
                latitude: userLocation.latitude + 0.008,
                longitude: userLocation.longitude - 0.002,
                rating: 4.0,
                phoneNumber: '+48 42 631 45 67',
                distanceFromUser: 0.8,
                formattedDistance: '0.8 km'
            },
        ];

        return sampleStores;
    };

    const getStoreColor = (storeName: string): string => {
        const colors: {[key: string]: string} = {
            'Biedronka': '#E60000',
            'Lidl': '#005BA9',
            'Carrefour': '#004B9D',
            'Żabka': '#00A651',
            'Auchan': '#FF6B00',
        };
        return colors[storeName] || '#9b59b6';
    };

    const openInGoogleMaps = (store: Store) => {
        const url = `https://www.google.com/maps/search/?api=1&query=${store.latitude},${store.longitude}`;
        Linking.openURL(url).catch(() => {
            Alert.alert('Błąd', 'Nie można otworzyć Google Maps');
        });
    };

    const recenterMap = () => {
        if (userLocation) {
            moveCameraToLocation(userLocation);
        }
    };

    if (loading || locationLoading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#3498db" />
                <Text style={styles.loadingText}>
                    {locationLoading ? 'Pobieranie lokalizacji...' : 'Ładowanie mapy...'}
                </Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            {/* MAPA */}
            <MapView
                ref={mapRef}
                style={styles.map}
                provider={PROVIDER_DEFAULT}
                initialRegion={userLocation || defaultRegion}
                showsUserLocation={true}
                showsMyLocationButton={false}
                showsCompass={true}
                showsScale={true}
                onPress={() => setSelectedStore(null)}
            >
                {userLocation && (
                    <Circle
                        center={{
                            latitude: userLocation.latitude,
                            longitude: userLocation.longitude,
                        }}
                        radius={radius * 1000} // km na metry
                        strokeWidth={2}
                        strokeColor="rgba(52, 152, 219, 0.5)"
                        fillColor="rgba(52, 152, 219, 0.2)"
                    />
                )}

                {stores.map((store) => (
                    <Marker
                        key={store.id}
                        coordinate={{
                            latitude: store.latitude,
                            longitude: store.longitude,
                        }}
                        title={store.name}
                        description={store.formattedDistance || store.address}
                        onPress={() => setSelectedStore(store)}
                    >
                        <View style={[
                            styles.marker,
                            { backgroundColor: getStoreColor(store.name) }
                        ]}>
                            <Text style={styles.markerText}>
                                {store.name.charAt(0)}
                            </Text>
                        </View>
                    </Marker>
                ))}
            </MapView>

            <View style={styles.controlsContainer}>
                <TouchableOpacity
                    style={styles.controlButton}
                    onPress={recenterMap}
                >
                    <Icon name="my-location" size={24} color="#2c3e50" />
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.controlButton}
                    onPress={getUserLocation}
                >
                    <Icon name="gps-fixed" size={24} color="#2c3e50" />
                </TouchableOpacity>
            </View>

            <View style={styles.radiusPanel}>
                <Text style={styles.radiusTitle}>Promień: {radius} km</Text>
                <View style={styles.radiusButtons}>
                    {[1, 3, 5, 10].map((r) => (
                        <TouchableOpacity
                            key={r}
                            style={[styles.radiusButton, radius === r && styles.activeRadiusButton]}
                            onPress={() => setRadius(r)}
                        >
                            <Text style={[styles.radiusText, radius === r && styles.activeRadiusText]}>
                                {r} km
                            </Text>
                        </TouchableOpacity>
                    ))}
                </View>
            </View>

            {selectedStore ? (
                <View style={styles.storeDetailsPanel}>
                    <View style={styles.storeHeader}>
                        <View style={[
                            styles.storeIcon,
                            { backgroundColor: getStoreColor(selectedStore.name) }
                        ]}>
                            <Text style={styles.storeIconText}>
                                {selectedStore.name.charAt(0)}
                            </Text>
                        </View>
                        <View style={styles.storeInfo}>
                            <Text style={styles.storeName}>{selectedStore.name}</Text>
                            <Text style={styles.storeAddress}>{selectedStore.address}</Text>
                            {selectedStore.formattedDistance && (
                                <Text style={styles.storeDistance}>
                                    📍 {selectedStore.formattedDistance}
                                </Text>
                            )}
                        </View>
                        <TouchableOpacity
                            onPress={() => setSelectedStore(null)}
                        >
                            <Icon name="close" size={24} color="#7f8c8d" />
                        </TouchableOpacity>
                    </View>

                    <View style={styles.storeActions}>
                        {selectedStore.phoneNumber && (
                            <TouchableOpacity
                                style={styles.actionButton}
                                onPress={() => Linking.openURL(`tel:${selectedStore.phoneNumber}`)}
                            >
                                <Icon name="phone" size={20} color="white" />
                                <Text style={styles.actionText}>Zadzwoń</Text>
                            </TouchableOpacity>
                        )}

                        <TouchableOpacity
                            style={[styles.actionButton, { backgroundColor: '#2ecc71' }]}
                            onPress={() => openInGoogleMaps(selectedStore)}
                        >
                            <Icon name="map" size={20} color="white" />
                            <Text style={styles.actionText}>Pokaż w Google Maps</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            ) : (
                <View style={styles.storesList}>
                    <Text style={styles.storesTitle}>Sklepy w okolicy ({stores.length})</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {stores.map((store) => (
                            <TouchableOpacity
                                key={store.id}
                                style={styles.storeCard}
                                onPress={() => {
                                    setSelectedStore(store);
                                    moveCameraToLocation({
                                        latitude: store.latitude,
                                        longitude: store.longitude,
                                        latitudeDelta: 0.01,
                                        longitudeDelta: 0.01,
                                    });
                                }}
                            >
                                <View style={[
                                    styles.storeCardIcon,
                                    { backgroundColor: getStoreColor(store.name) }
                                ]}>
                                    <Text style={styles.storeCardIconText}>
                                        {store.name.charAt(0)}
                                    </Text>
                                </View>
                                <Text style={styles.storeCardName}>{store.name}</Text>
                                <Text style={styles.storeCardDistance}>
                                    {store.formattedDistance}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </ScrollView>
                </View>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8f9fa',
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    loadingText: {
        marginTop: 10,
        color: '#7f8c8d',
    },
    map: {
        width: '100%',
        height: '70%',
    },
    controlsContainer: {
        position: 'absolute',
        top: 20,
        right: 20,
        backgroundColor: 'white',
        borderRadius: 25,
        padding: 10,
        flexDirection: 'row',
        gap: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    controlButton: {
        width: 44,
        height: 44,
        borderRadius: 22,
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: '#ecf0f1',
    },
    radiusPanel: {
        position: 'absolute',
        top: 20,
        left: 20,
        right: 100,
        backgroundColor: 'white',
        borderRadius: 12,
        padding: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    radiusTitle: {
        fontSize: 14,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 10,
    },
    radiusButtons: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    radiusButton: {
        flex: 1,
        paddingVertical: 8,
        marginHorizontal: 4,
        backgroundColor: '#ecf0f1',
        borderRadius: 8,
        alignItems: 'center',
    },
    activeRadiusButton: {
        backgroundColor: '#3498db',
    },
    radiusText: {
        fontSize: 12,
        color: '#7f8c8d',
        fontWeight: '500',
    },
    activeRadiusText: {
        color: 'white',
    },
    marker: {
        width: 36,
        height: 36,
        borderRadius: 18,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 2,
        borderColor: 'white',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 3,
        elevation: 4,
    },
    markerText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 16,
    },
    storeDetailsPanel: {
        position: 'absolute',
        bottom: 20,
        left: 20,
        right: 20,
        backgroundColor: 'white',
        borderRadius: 16,
        padding: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 5,
    },
    storeHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    storeIcon: {
        width: 50,
        height: 50,
        borderRadius: 25,
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 15,
    },
    storeIconText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 22,
    },
    storeInfo: {
        flex: 1,
    },
    storeName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginBottom: 4,
    },
    storeAddress: {
        fontSize: 12,
        color: '#7f8c8d',
        marginBottom: 4,
    },
    storeDistance: {
        fontSize: 13,
        color: '#3498db',
        fontWeight: '600',
    },
    storeActions: {
        flexDirection: 'row',
        gap: 10,
    },
    actionButton: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#3498db',
        paddingVertical: 12,
        borderRadius: 10,
        gap: 8,
    },
    actionText: {
        color: 'white',
        fontSize: 14,
        fontWeight: '600',
    },
    storesList: {
        position: 'absolute',
        bottom: 20,
        left: 20,
        right: 20,
    },
    storesTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 10,
    },
    storeCard: {
        width: 100,
        backgroundColor: 'white',
        borderRadius: 12,
        padding: 15,
        marginRight: 10,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    storeCardIcon: {
        width: 40,
        height: 40,
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 10,
    },
    storeCardIconText: {
        color: 'white',
        fontWeight: 'bold',
        fontSize: 18,
    },
    storeCardName: {
        fontSize: 14,
        fontWeight: '600',
        color: '#2c3e50',
        textAlign: 'center',
        marginBottom: 4,
    },
    storeCardDistance: {
        fontSize: 12,
        color: '#3498db',
        fontWeight: '600',
        textAlign: 'center',
    },
});