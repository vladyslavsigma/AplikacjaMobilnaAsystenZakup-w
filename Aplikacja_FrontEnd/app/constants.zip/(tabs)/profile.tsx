import React, { useState, useEffect } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Alert,
    Switch,
    ActivityIndicator
} from 'react-native';
import { router } from 'expo-router';
import Icon from 'react-native-vector-icons/MaterialIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function ProfileScreen() {
    const [userInfo, setUserInfo] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const [notificationsEnabled, setNotificationsEnabled] = useState(true);

    useEffect(() => {
        loadUserProfile();
    }, []);

    const loadUserProfile = async () => {
        try {
            const username = await AsyncStorage.getItem('username');
            const email = await AsyncStorage.getItem('email');

            setUserInfo({
                username,
                email,
                joinDate: new Date().toISOString(),
            });
        } catch (error) {
            console.error('Error loading profile:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleLogout = async () => {
        Alert.alert(
            'Wylogowanie',
            'Czy na pewno chcesz się wylogować?',
            [
                { text: 'Anuluj', style: 'cancel' },
                {
                    text: 'Wyloguj',
                    style: 'destructive',
                    onPress: async () => {
                        await AsyncStorage.clear();
                        router.replace('/(auth)/login');
                    }
                }
            ]
        );
    };

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#3498db" />
                <Text style={styles.loadingText}>Ładowanie profilu...</Text>
            </View>
        );
    }

    return (
        <ScrollView style={styles.container}>
            <View style={styles.profileHeader}>
                <View style={styles.avatar}>
                    <Icon name="person" size={50} color="white" />
                </View>

                <Text style={styles.userName}>{userInfo?.username || 'Użytkownik'}</Text>
                <Text style={styles.userEmail}>{userInfo?.email || 'brak@email.com'}</Text>
            </View>

            <View style={styles.section}>
                <Text style={styles.sectionTitle}>⚙️ Ustawienia</Text>

                <View style={styles.settingItem}>
                    <View style={styles.settingInfo}>
                        <Icon name="notifications" size={24} color="#3498db" />
                        <View style={styles.settingText}>
                            <Text style={styles.settingTitle}>Powiadomienia</Text>
                            <Text style={styles.settingDescription}>Otrzymuj przypomnienia o zakupach</Text>
                        </View>
                    </View>
                    <Switch
                        value={notificationsEnabled}
                        onValueChange={setNotificationsEnabled}
                        trackColor={{ false: '#bdc3c7', true: '#3498db' }}
                    />
                </View>
            </View>

            <TouchableOpacity style={styles.menuItem}>
                <View style={styles.menuItemLeft}>
                    <Icon name="edit" size={24} color="#3498db" />
                    <Text style={styles.menuItemText}>Edytuj profil</Text>
                </View>
                <Icon name="chevron-right" size={24} color="#95a5a6" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuItem}>
                <View style={styles.menuItemLeft}>
                    <Icon name="help" size={24} color="#9b59b6" />
                    <Text style={styles.menuItemText}>Centrum pomocy</Text>
                </View>
                <Icon name="chevron-right" size={24} color="#95a5a6" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.menuItem}>
                <View style={styles.menuItemLeft}>
                    <Icon name="info" size={24} color="#3498db" />
                    <Text style={styles.menuItemText}>O aplikacji</Text>
                </View>
                <Icon name="chevron-right" size={24} color="#95a5a6" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
                <Icon name="logout" size={24} color="#e74c3c" />
                <Text style={styles.logoutButtonText}>Wyloguj się</Text>
            </TouchableOpacity>

            <View style={styles.footer}>
                <Text style={styles.versionText}>Wersja 1.2.1</Text>
                <Text style={styles.copyrightText}>© 2026 Asystent Zakupów</Text>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8f9fa',
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    loadingText: {
        marginTop: 10,
        color: '#7f8c8d',
    },
    profileHeader: {
        backgroundColor: 'white',
        alignItems: 'center',
        paddingVertical: 30,
        marginBottom: 15,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
        elevation: 2,
    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: '#3498db',
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 15,
    },
    userName: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginBottom: 5,
    },
    userEmail: {
        fontSize: 16,
        color: '#7f8c8d',
    },
    section: {
        backgroundColor: 'white',
        marginHorizontal: 15,
        marginBottom: 15,
        borderRadius: 12,
        padding: 20,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
        elevation: 2,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginBottom: 15,
    },
    settingItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 10,
    },
    settingInfo: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
    },
    settingText: {
        marginLeft: 15,
        flex: 1,
    },
    settingTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 2,
    },
    settingDescription: {
        fontSize: 12,
        color: '#7f8c8d',
    },
    menuItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        backgroundColor: 'white',
        marginHorizontal: 15,
        marginBottom: 10,
        padding: 15,
        borderRadius: 12,
    },
    menuItemLeft: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
    },
    menuItemText: {
        fontSize: 16,
        color: '#2c3e50',
        marginLeft: 15,
    },
    logoutButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        marginHorizontal: 15,
        marginTop: 20,
        padding: 18,
        borderRadius: 12,
        gap: 10,
    },
    logoutButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#e74c3c',
    },
    footer: {
        alignItems: 'center',
        paddingVertical: 20,
        paddingHorizontal: 15,
        marginTop: 20,
    },
    versionText: {
        fontSize: 14,
        color: '#95a5a6',
        marginBottom: 5,
    },
    copyrightText: {
        fontSize: 12,
        color: '#bdc3c7',
    },
});