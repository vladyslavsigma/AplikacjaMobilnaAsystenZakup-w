import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  RefreshControl
} from 'react-native';
import { router } from 'expo-router';
import Icon from 'react-native-vector-icons/MaterialIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Config from '../constants/Config';
const API_BASE_URL = Config.API_BASE_URL;

interface PriceComparison {
  storePrices: {
    [store: string]: number;
  };
  cheapestStore?: string;
  cheapestPrice?: number;
}

interface ShoppingItem {
  id: string;
  _id?: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  notes?: string;
  priceComparison?: PriceComparison;
}

interface ShoppingList {
  id: string;
  _id?: string;
  name: string;
  description?: string;
  createdAt: string;
  items: ShoppingItem[];
}

interface UserStats {
  listCount: number;
  productCount: number;
  totalSavings: number;
  recentLists: ShoppingList[];
}

export default function DashboardScreen() {
  const [userInfo, setUserInfo] = useState<any>(null);
  const [stats, setStats] = useState<UserStats>({
    listCount: 0,
    productCount: 0,
    totalSavings: 0,
    recentLists: []
  });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);

      const username = await AsyncStorage.getItem('username');
      const email = await AsyncStorage.getItem('email');
      setUserInfo({ username, email });

      await loadUserStats(email || 'demo-user');

    } catch (error) {
      console.error('Error loading dashboard data:', error);
      Alert.alert('Błąd', 'Nie udało się załadować danych dashboardu');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const loadUserStats = async (userId: string) => {
    try {
      console.log('Pobieranie statystyk dla użytkownika:', userId);

      const response = await fetch(`${API_BASE_URL}/shopping/lists?userId=${userId}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
        },
      });

      console.log('Status pobierania list:', response.status);

      if (response.ok) {
        const lists: ShoppingList[] = await response.json();
        console.log('Otrzymane listy:', lists.length);

        let totalProducts = 0;
        let totalSavings = 0;

        lists.forEach(list => {
          if (list.items && Array.isArray(list.items)) {
            totalProducts += list.items.length;

            list.items.forEach(item => {
              if (item.priceComparison && item.priceComparison.storePrices) {
                const storePrices = item.priceComparison.storePrices;
                const prices: number[] = [];

                for (const store in storePrices) {
                  if (storePrices.hasOwnProperty(store)) {
                    const price = storePrices[store];
                    if (typeof price === 'number' && price > 0) {
                      prices.push(price);
                    }
                    else if (typeof price === 'string') {
                      const numPrice = parseFloat(price);
                      if (!isNaN(numPrice) && numPrice > 0) {
                        prices.push(numPrice);
                      }
                    }
                  }
                }

                if (prices.length > 1) {
                  const minPrice = Math.min(...prices);
                  const maxPrice = Math.max(...prices);
                  const saving = maxPrice - minPrice;
                  const quantity = item.quantity || 1;
                  totalSavings += saving * quantity;
                }
              }
            });
          }
        });

        const sortedLists = [...lists].sort((a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );

        const recentLists = sortedLists.slice(0, 3);

        setStats({
          listCount: lists.length,
          productCount: totalProducts,
          totalSavings: parseFloat(totalSavings.toFixed(2)),
          recentLists: recentLists
        });

      } else {
        const errorText = await response.text();
        console.error('Błąd pobierania statystyk:', errorText);

        useSampleStats();
      }
    } catch (error) {
      console.error('Error loading stats:', error);

      useSampleStats();
    }
  };

  const useSampleStats = () => {
    const sampleLists: ShoppingList[] = [
      {
        id: '1',
        name: 'Zakupy na weekend',
        description: 'Produkty na sobotę i niedzielę',
        createdAt: new Date().toISOString(),
        items: [
          {
            id: '1',
            name: 'Mleko',
            category: 'Nabiał',
            quantity: 2,
            unit: 'litr',
            priceComparison: {
              storePrices: {
                'Biedronka': 3.20,
                'Lidl': 3.10,
                'Carrefour': 3.50
              },
              cheapestStore: 'Lidl',
              cheapestPrice: 3.10
            }
          },
          {
            id: '2',
            name: 'Chleb',
            category: 'Pieczywo',
            quantity: 1,
            unit: 'szt',
            priceComparison: {
              storePrices: {
                'Biedronka': 4.50,
                'Lidl': 4.20,
                'Carrefour': 4.80
              },
              cheapestStore: 'Lidl',
              cheapestPrice: 4.20
            }
          }
        ]
      },
      {
        id: '2',
        name: 'Lista podstawowa',
        description: 'Produkty codziennego użytku',
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        items: [
          {
            id: '3',
            name: 'Masło',
            category: 'Nabiał',
            quantity: 1,
            unit: 'szt',
            priceComparison: {
              storePrices: {
                'Biedronka': 6.50,
                'Lidl': 6.20,
                'Carrefour': 7.00
              },
              cheapestStore: 'Lidl',
              cheapestPrice: 6.20
            }
          }
        ]
      }
    ];

    let sampleSavings = 0;
    sampleLists.forEach(list => {
      list.items.forEach(item => {
        if (item.priceComparison && item.priceComparison.storePrices) {
          const prices = Object.values(item.priceComparison.storePrices);
          if (prices.length > 1) {
            const minPrice = Math.min(...prices);
            const maxPrice = Math.max(...prices);
            const saving = maxPrice - minPrice;
            sampleSavings += saving * item.quantity;
          }
        }
      });
    });

    setStats({
      listCount: sampleLists.length,
      productCount: 3,
      totalSavings: parseFloat(sampleSavings.toFixed(2)),
      recentLists: sampleLists
    });
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadDashboardData();
  };

  const handleLogout = async () => {
    Alert.alert(
        'Wylogowanie',
        'Czy na pewno chcesz się wylogować?',
        [
          { text: 'Anuluj', style: 'cancel' },
          {
            text: 'Wyloguj',
            style: 'destructive',
            onPress: async () => {
              await AsyncStorage.clear();
              router.replace('/(auth)/login');
            }
          }
        ]
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pl-PL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  if (loading) {
    return (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3498db" />
          <Text style={styles.loadingText}>Ładowanie dashboardu...</Text>
        </View>
    );
  }

  return (
      <ScrollView
          style={styles.container}
          refreshControl={
            <RefreshControl
                refreshing={refreshing}
                onRefresh={onRefresh}
                colors={['#3498db']}
            />
          }
      >
        <View style={styles.header}>
          <View style={styles.userInfo}>
            <View style={styles.avatar}>
              <Icon name="person" size={40} color="white" />
            </View>
            <View style={styles.userText}>
              <Text style={styles.welcomeText}>Witaj,</Text>
              <Text style={styles.username}>{userInfo?.username || 'Użytkowniku'}!</Text>
              <Text style={styles.userEmail}>{userInfo?.email || ''}</Text>
            </View>
          </View>

          <TouchableOpacity onPress={handleLogout} style={styles.logoutButton}>
            <Icon name="logout" size={24} color="#e74c3c" />
            <Text style={styles.logoutButtonText}>Wyloguj</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.statsContainer}>
          <Text style={styles.sectionTitle}>📊 Twoje statystyki</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <Icon name="list-alt" size={30} color="#3498db" />
              <Text style={styles.statNumber}>{stats.listCount}</Text>
              <Text style={styles.statLabel}>Listy</Text>
            </View>

            <View style={styles.statCard}>
              <Icon name="shopping-basket" size={30} color="#2ecc71" />
              <Text style={styles.statNumber}>{stats.productCount}</Text>
              <Text style={styles.statLabel}>Produkty</Text>
            </View>

            <View style={styles.statCard}>
              <Icon name="savings" size={30} color="#f39c12" />
              <Text style={styles.statNumber}>{stats.totalSavings.toFixed(2)} zł</Text>
              <Text style={styles.statLabel}>Oszczędności</Text>
            </View>
          </View>

          {stats.totalSavings > 0 && (
              <View style={styles.savingsInfo}>
                <Icon name="info" size={16} color="#3498db" />
                <Text style={styles.savingsText}>
                  Zaoszczędziłeś {stats.totalSavings.toFixed(2)} zł porównując ceny!
                </Text>
              </View>
          )}
        </View>

        <View style={styles.actionsContainer}>
          <Text style={styles.sectionTitle}>⚡ Szybkie akcje</Text>
          <View style={styles.actionsGrid}>
            <TouchableOpacity
                style={styles.actionButton}
                onPress={() => router.push('/(tabs)/lists/create')}
            >
              <Icon name="add" size={30} color="white" />
              <Text style={styles.actionText}>Nowa lista</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style={[styles.actionButton, { backgroundColor: '#2ecc71' }]}
                onPress={() => router.push('/(tabs)/map')}
            >
              <Icon name="map" size={30} color="white" />
              <Text style={styles.actionText}>Znajdź sklepy</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style={[styles.actionButton, { backgroundColor: '#9b59b6' }]}
                onPress={() => router.push('/(tabs)/profile')}
            >
              <Icon name="settings" size={30} color="white" />
              <Text style={styles.actionText}>Ustawienia</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.listsContainer}>
          <View style={styles.listsHeader}>
            <Text style={styles.sectionTitle}>🛒 Ostatnie listy</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/lists')}>
              <Text style={styles.seeAllText}>Zobacz wszystkie →</Text>
            </TouchableOpacity>
          </View>

          {stats.recentLists.length === 0 ? (
              <View style={styles.emptyLists}>
                <Icon name="shopping-cart" size={50} color="#bdc3c7" />
                <Text style={styles.emptyText}>Brak list zakupów</Text>
                <Text style={styles.emptySubtext}>Utwórz swoją pierwszą listę!</Text>
                <TouchableOpacity
                    style={styles.createFirstButton}
                    onPress={() => router.push('/(tabs)/lists/create')}
                >
                  <Text style={styles.createFirstButtonText}>Utwórz pierwszą listę</Text>
                </TouchableOpacity>
              </View>
          ) : (
              <View style={styles.recentLists}>
                {stats.recentLists.map(list => (
                    <TouchableOpacity
                        key={list.id || list._id}
                        style={styles.listCard}
                        onPress={() => router.push(`/(tabs)/lists/${list.id || list._id}`)}
                    >
                      <View style={styles.listCardHeader}>
                        <Icon name="list-alt" size={24} color="#3498db" />
                        <View style={styles.listCardInfo}>
                          <Text style={styles.listCardName} numberOfLines={1}>
                            {list.name}
                          </Text>
                          {list.description && (
                              <Text style={styles.listCardDesc} numberOfLines={1}>
                                {list.description}
                              </Text>
                          )}
                        </View>
                      </View>

                      <View style={styles.listCardDetails}>
                        <View style={styles.listCardStat}>
                          <Icon name="shopping-basket" size={14} color="#7f8c8d" />
                          <Text style={styles.listCardStatText}>
                            {list.items?.length || 0} produktów
                          </Text>
                        </View>
                        <Text style={styles.listCardDate}>
                          {formatDate(list.createdAt)}
                        </Text>
                      </View>

                      <TouchableOpacity
                          style={styles.listCardButton}
                          onPress={() => router.push(`/(tabs)/lists/${list.id || list._id}`)}
                      >
                        <Text style={styles.listCardButtonText}>Otwórz</Text>
                        <Icon name="chevron-right" size={16} color="#3498db" />
                      </TouchableOpacity>
                    </TouchableOpacity>
                ))}

                <TouchableOpacity
                    style={styles.seeAllCard}
                    onPress={() => router.push('/(tabs)/lists')}
                >
                  <Icon name="list" size={30} color="#3498db" />
                  <Text style={styles.seeAllCardText}>Zobacz wszystkie listy</Text>
                  <Icon name="arrow-forward" size={20} color="#3498db" />
                </TouchableOpacity>
              </View>
          )}
        </View>

        <View style={styles.updateInfo}>
          <Text style={styles.updateText}>
            Ostatnia aktualizacja: {new Date().toLocaleTimeString('pl-PL', {
            hour: '2-digit',
            minute: '2-digit'
          })}
          </Text>
          <TouchableOpacity onPress={onRefresh}>
            <Text style={styles.updateButtonText}>↻ Odśwież</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: '#7f8c8d',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 20,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#3498db',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  userText: {
    flex: 1,
  },
  welcomeText: {
    fontSize: 14,
    color: '#7f8c8d',
  },
  username: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2c3e50',
  },
  userEmail: {
    fontSize: 12,
    color: '#95a5a6',
    marginTop: 2,
  },
  logoutButton: {
    marginLeft: 15,
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: '#ffeaea',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#ffcccc',
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 70,
  },
  logoutButtonText: {
    color: '#e74c3c',
    fontSize: 11,
    marginTop: 2,
    fontWeight: '600',
  },
  statsContainer: {
    backgroundColor: 'white',
    marginHorizontal: 15,
    marginBottom: 15,
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: 15,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statCard: {
    alignItems: 'center',
    flex: 1,
    padding: 10,
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#2c3e50',
    marginTop: 5,
  },
  statLabel: {
    fontSize: 12,
    color: '#7f8c8d',
    marginTop: 2,
  },
  savingsInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e8f4fc',
    padding: 10,
    borderRadius: 8,
    marginTop: 15,
    gap: 8,
  },
  savingsText: {
    flex: 1,
    fontSize: 14,
    color: '#3498db',
    fontWeight: '500',
  },
  actionsContainer: {
    backgroundColor: 'white',
    marginHorizontal: 15,
    marginBottom: 15,
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  actionsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#3498db',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  actionText: {
    color: 'white',
    fontSize: 12,
    marginTop: 5,
    textAlign: 'center',
  },
  listsContainer: {
    backgroundColor: 'white',
    marginHorizontal: 15,
    marginBottom: 15,
    padding: 20,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  listsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  seeAllText: {
    color: '#3498db',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyLists: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  emptyText: {
    fontSize: 16,
    color: '#7f8c8d',
    marginTop: 10,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#bdc3c7',
    marginTop: 5,
  },
  createFirstButton: {
    backgroundColor: '#3498db',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 15,
  },
  createFirstButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  recentLists: {
    gap: 12,
  },
  listCard: {
    backgroundColor: '#f8f9fa',
    borderRadius: 10,
    padding: 15,
    borderWidth: 1,
    borderColor: '#ecf0f1',
  },
  listCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    gap: 12,
  },
  listCardInfo: {
    flex: 1,
  },
  listCardName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2c3e50',
    marginBottom: 2,
  },
  listCardDesc: {
    fontSize: 12,
    color: '#7f8c8d',
  },
  listCardDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  listCardStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  listCardStatText: {
    fontSize: 12,
    color: '#7f8c8d',
  },
  listCardDate: {
    fontSize: 12,
    color: '#95a5a6',
  },
  listCardButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    paddingVertical: 8,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: '#3498db',
    gap: 5,
  },
  listCardButtonText: {
    color: '#3498db',
    fontSize: 14,
    fontWeight: '600',
  },
  seeAllCard: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#e8f4fc',
    padding: 15,
    borderRadius: 10,
    gap: 10,
    marginTop: 5,
  },
  seeAllCardText: {
    color: '#3498db',
    fontSize: 14,
    fontWeight: '600',
  },
  tipContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff8e1',
    marginHorizontal: 15,
    marginBottom: 15,
    padding: 15,
    borderRadius: 12,
    borderLeftWidth: 4,
    borderLeftColor: '#f39c12',
  },
  tipText: {
    flex: 1,
    marginLeft: 10,
    fontSize: 14,
    color: '#8e6c0a',
    fontStyle: 'italic',
  },
  updateInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  updateText: {
    fontSize: 12,
    color: '#bdc3c7',
  },
  updateButtonText: {
    fontSize: 12,
    color: '#3498db',
    fontWeight: '600',
  },
});