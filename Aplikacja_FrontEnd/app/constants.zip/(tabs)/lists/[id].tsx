import React, { useState, useEffect, useRef } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    Alert,
    TextInput,
    Modal,
    ActivityIndicator,
    RefreshControl
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import Icon from 'react-native-vector-icons/MaterialIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Config from '../../constants/Config';
const API_BASE_URL = Config.API_BASE_URL;

interface ShoppingItem {
    id: string;
    _id?: string;
    name: string;
    category: string;
    quantity: number;
    unit: string;
    notes?: string;
    priceComparison?: {
        storePrices: { [store: string]: number };
        cheapestStore?: string;
        cheapestPrice?: number;
    };
}

interface ShoppingList {
    id: string;
    _id?: string;
    name: string;
    description?: string;
    createdAt: string;
    userId?: string;
    items: ShoppingItem[];
}

export default function ListDetailScreen() {
    const { id } = useLocalSearchParams();
    const [list, setList] = useState<ShoppingList | null>(null);
    const [items, setItems] = useState<ShoppingItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [refreshing, setRefreshing] = useState(false);
    const [modalVisible, setModalVisible] = useState(false);
    const [newItem, setNewItem] = useState({
        name: '',
        category: 'Inne',
        quantity: 1,
        unit: 'szt',
        notes: ''
    });
    const [stores] = useState(['Biedronka', 'Lidl', 'Carrefour', 'Auchan']);

    const scrollViewRef = useRef<ScrollView>(null);

    useEffect(() => {
        fetchListDetails();
    }, [id]);

    const fetchListDetails = async () => {
        try {
            setLoading(true);

            const email = await AsyncStorage.getItem('email');
            const userId = email || 'demo-user';

            console.log('Pobieranie listy:', id, 'dla userId:', userId);

            const response = await fetch(`${API_BASE_URL}/shopping/lists/${id}?userId=${userId}`, {
                method: 'GET',
                headers: {
                    'Accept': 'application/json',
                },
            });

            console.log('Status odpowiedzi:', response.status);

            if (response.ok) {
                const listData = await response.json();
                console.log('Otrzymane dane listy:', listData);

                const normalizedList = {
                    ...listData,
                    id: listData._id || listData.id,
                    items: listData.items || []
                };

                setList(normalizedList);
                setItems(normalizedList.items || []);
            } else {
                const errorText = await response.text();
                console.error('Błąd pobierania listy:', errorText);
                Alert.alert('Błąd', 'Nie udało się załadować listy');
            }
        } catch (error) {
            console.error('Error fetching list:', error);
            Alert.alert('Błąd', 'Nie udało się połączyć z serwerem');
        } finally {
            setLoading(false);
            setRefreshing(false);
        }
    };

    const addItem = async () => {
        if (!newItem.name.trim()) {
            Alert.alert('Błąd', 'Wprowadź nazwę produktu');
            return;
        }

        try {
            if (!list) return;

            const email = await AsyncStorage.getItem('email');
            const userId = email || 'demo-user';

            console.log('Dodawanie produktu do listy:', list.id);

            const response = await fetch(`${API_BASE_URL}/shopping/lists/${list.id}/items?userId=${userId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    name: newItem.name,
                    category: newItem.category,
                    quantity: newItem.quantity,
                    unit: newItem.unit,
                    notes: newItem.notes
                }),
            });

            console.log('Status dodawania produktu:', response.status);

            if (response.ok) {
                const updatedList = await response.json();
                console.log('Zaktualizowana lista po dodaniu produktu:', updatedList);

                setList(updatedList);
                setItems(updatedList.items || []);

                setNewItem({ name: '', category: 'Inne', quantity: 1, unit: 'szt', notes: '' });
                setModalVisible(false);
                Alert.alert('Sukces', 'Produkt dodany do listy');
            } else {
                const errorText = await response.text();
                console.error('Błąd dodawania produktu:', errorText);
                Alert.alert('Błąd', 'Nie udało się dodać produktu');
            }
        } catch (error) {
            console.error('Error adding item:', error);
            Alert.alert('Błąd', 'Nie udało się połączyć z serwerem');
        }
    };

    const removeItem = async (itemId: string) => {
        Alert.alert(
            'Usuwanie produktu',
            'Czy na pewno chcesz usunąć ten produkt z listy?',
            [
                { text: 'Anuluj', style: 'cancel' },
                {
                    text: 'Usuń',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            if (!list) return;

                            const email = await AsyncStorage.getItem('email');
                            const userId = email || 'demo-user';

                            console.log('Usuwanie produktu:', itemId, 'z listy:', list.id);

                            const response = await fetch(`${API_BASE_URL}/shopping/lists/${list.id}/items/${itemId}?userId=${userId}`, {
                                method: 'DELETE',
                            });

                            console.log('Status usuwania produktu:', response.status);

                            if (response.ok) {
                                const updatedList = await response.json();
                                console.log('Zaktualizowana lista po usunięciu produktu:', updatedList);

                                setList(updatedList);
                                setItems(updatedList.items || []);
                                Alert.alert('Sukces', 'Produkt usunięty z listy');
                            } else {
                                const errorText = await response.text();
                                console.error('Błąd usuwania produktu:', errorText);
                                Alert.alert('Błąd', 'Nie udało się usunąć produktu');
                            }
                        } catch (error) {
                            console.error('Error removing item:', error);
                            Alert.alert('Błąd', 'Nie udało się połączyć z serwerem');
                        }
                    }
                }
            ]
        );
    };

    const updatePrice = async (itemId: string, store: string, price: string) => {
        const priceNum = parseFloat(price.replace(',', '.'));
        if (isNaN(priceNum) || priceNum < 0) {
            Alert.alert('Błąd', 'Wprowadź poprawną cenę');
            return;
        }

        try {
            if (!list) return;

            const email = await AsyncStorage.getItem('email');
            const userId = email || 'demo-user';

            console.log('Aktualizacja ceny dla produktu:', itemId, 'sklep:', store, 'cena:', priceNum);

            const response = await fetch(`${API_BASE_URL}/shopping/lists/${list.id}/items/${itemId}/price?userId=${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ store, price: priceNum }),
            });

            console.log('Status aktualizacji ceny:', response.status);

            if (response.ok) {
                const updatedList = await response.json();
                console.log('Zaktualizowana lista po zmianie ceny:', updatedList);

                setList(updatedList);
                setItems(updatedList.items || []);

                // Informacja o zapisaniu ceny
                Alert.alert('Sukces', 'Cena została zapisana!');
            } else {
                const errorText = await response.text();
                console.error('Błąd aktualizacji ceny:', errorText);
                Alert.alert('Błąd', 'Nie udało się zapisać ceny');
            }
        } catch (error) {
            console.error('Error updating price:', error);
            Alert.alert('Błąd', 'Nie udało się połączyć z serwerem');
        }
    };

    const updateQuantity = async (itemId: string, newQuantity: number) => {
        try {
            if (!list) return;

            // 1. LOKALNA AKTUALIZACJA - natychmiastowa zmiana w UI
            const updatedItems = items.map(item =>
                (item.id === itemId || item._id === itemId)
                    ? { ...item, quantity: Math.max(1, newQuantity) }
                    : item
            );
            setItems(updatedItems);

            const email = await AsyncStorage.getItem('email');
            const userId = email || 'demo-user';

            console.log('Aktualizacja ilości dla produktu:', itemId, 'nowa ilość:', newQuantity);

            const itemToUpdate = items.find(item => item.id === itemId || item._id === itemId);
            if (!itemToUpdate) return;

            const response = await fetch(`${API_BASE_URL}/shopping/lists/${list.id}/items/${itemId}?userId=${userId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    ...itemToUpdate,
                    quantity: newQuantity
                }),
            });

            console.log('Status aktualizacji ilości:', response.status);

            if (response.ok) {
                const updatedList = await response.json();
                console.log('Zaktualizowana lista po zmianie ilości:', updatedList);

                // 2. SYNCHRONIZACJA Z BACKENDEM
                setList(updatedList);
                setItems(updatedList.items || []);
            } else {
                const errorText = await response.text();
                console.error('Błąd aktualizacji ilości:', errorText);
                // Nie pokazujemy alertu - UI już zostało zaktualizowane
            }
        } catch (error) {
            console.error('Error updating quantity:', error);
            // Nie pokazujemy alertu - UI już zostało zaktualizowane
        }
    };

    const updateListInfo = async (field: 'name' | 'description', value: string) => {
        try {
            if (!list) return;

            const email = await AsyncStorage.getItem('email');
            const userId = email || 'demo-user';

            console.log('Aktualizacja informacji listy:', field, '=', value);

            // Nie mamy endpointu do aktualizacji listy, więc pokażemy tylko info
            Alert.alert('Informacja',
                `Aby zmienić ${field === 'name' ? 'nazwę' : 'opis'} listy, przejdź do ekranu edycji listy.`,
                [{ text: 'OK' }]
            );
        } catch (error) {
            console.error('Error updating list info:', error);
        }
    };

    const calculateBestStore = () => {
        const storeTotals: { [store: string]: number } = {};

        stores.forEach(store => {
            storeTotals[store] = 0;
            items.forEach(item => {
                const price = item.priceComparison?.storePrices?.[store] || 0;
                storeTotals[store] += price * item.quantity;
            });
        });

        let bestStore = '';
        let bestPrice = Infinity;

        Object.entries(storeTotals).forEach(([store, total]) => {
            if (total > 0 && total < bestPrice) {
                bestPrice = total;
                bestStore = store;
            }
        });

        return { bestStore, bestPrice, storeTotals };
    };

    const onRefresh = () => {
        setRefreshing(true);
        fetchListDetails();
    };

    const { bestStore, bestPrice, storeTotals } = calculateBestStore();

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#3498db" />
                <Text style={styles.loadingText}>Ładowanie listy...</Text>
            </View>
        );
    }

    if (!list) {
        return (
            <View style={styles.loadingContainer}>
                <Icon name="error" size={50} color="#e74c3c" />
                <Text style={styles.errorText}>Nie udało się załadować listy</Text>
                <TouchableOpacity style={styles.backButtonLarge} onPress={() => router.back()}>
                    <Text style={styles.backButtonText}>Wróć do list</Text>
                </TouchableOpacity>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            {/* HEADER */}
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <Icon name="arrow-back" size={24} color="#2c3e50" />
                </TouchableOpacity>
                <View style={styles.headerInfo}>
                    <TouchableOpacity onPress={() => updateListInfo('name', list.name)}>
                        <Text style={styles.listName}>{list.name}</Text>
                    </TouchableOpacity>
                    {list.description && (
                        <TouchableOpacity onPress={() => updateListInfo('description', list.description || '')}>
                            <Text style={styles.listDescription}>{list.description}</Text>
                        </TouchableOpacity>
                    )}
                </View>
                <TouchableOpacity style={styles.addItemButton} onPress={() => setModalVisible(true)}>
                    <Icon name="add" size={20} color="white" />
                    <Text style={styles.addItemText}>Dodaj</Text>
                </TouchableOpacity>
            </View>

            {/* PRZYCISK ODSWIEŻANIA */}
            <View style={styles.actionButtonsContainer}>
                <TouchableOpacity
                    style={styles.refreshButton}
                    onPress={onRefresh}
                    disabled={refreshing}
                >
                    {refreshing ? (
                        <ActivityIndicator size="small" color="#3498db" />
                    ) : (
                        <>
                            <Icon name="refresh" size={20} color="#3498db" />
                            <Text style={styles.refreshButtonText}>Odśwież</Text>
                        </>
                    )}
                </TouchableOpacity>
            </View>

            {/* STATS */}
            <View style={styles.statsContainer}>
                <View style={styles.stat}>
                    <Icon name="shopping-basket" size={20} color="#3498db" />
                    <Text style={styles.statText}>{items.length} produktów</Text>
                </View>
                {bestStore && (
                    <View style={styles.stat}>
                        <Icon name="savings" size={20} color="#2ecc71" />
                        <Text style={styles.statText}>Najtaniej: {bestStore}</Text>
                    </View>
                )}
            </View>

            {/* NAGŁÓWEK Z CENAMI SKLEPÓW */}
            <View style={styles.storesHeaderContainer}>
                <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={true}
                    ref={scrollViewRef}
                    contentContainerStyle={styles.storesHeaderContent}
                >
                    <View style={styles.storePriceHeader}>
                        <View style={styles.productHeader}>
                            <Text style={styles.productHeaderText}>Produkt</Text>
                        </View>
                        {stores.map(store => (
                            <View key={store} style={styles.storeHeader}>
                                <Text style={styles.storeHeaderText}>{store}</Text>
                                <Text style={styles.storeTotal}>
                                    {storeTotals[store] > 0 ? `${storeTotals[store].toFixed(2)} zł` : '- zł'}
                                </Text>
                            </View>
                        ))}
                        <View style={styles.actionsHeader}>
                            <Text style={styles.actionsHeaderText}>Ilość</Text>
                        </View>
                    </View>
                </ScrollView>
            </View>

            {/* LISTA PRODUKTÓW */}
            <ScrollView
                style={styles.itemsContainer}
                refreshControl={
                    <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        colors={['#3498db']}
                    />
                }
            >
                {items.length === 0 ? (
                    <View style={styles.emptyItems}>
                        <Icon name="shopping-basket" size={50} color="#bdc3c7" />
                        <Text style={styles.emptyItemsText}>Brak produktów w liście</Text>
                        <Text style={styles.emptyItemsSubtext}>
                            Dodaj pierwszy produkt, aby zacząć porównywać ceny
                        </Text>
                        <TouchableOpacity
                            style={styles.addFirstButton}
                            onPress={() => setModalVisible(true)}
                        >
                            <Text style={styles.addFirstButtonText}>Dodaj pierwszy produkt</Text>
                        </TouchableOpacity>
                    </View>
                ) : (
                    items.map(item => {
                        const itemId = item.id || item._id || '';
                        const prices = item.priceComparison?.storePrices || {};
                        const cheapestStore = item.priceComparison?.cheapestStore;
                        const cheapestPrice = item.priceComparison?.cheapestPrice || 0;

                        return (
                            <View key={itemId} style={styles.itemCard}>
                                <ScrollView
                                    horizontal
                                    showsHorizontalScrollIndicator={true}
                                    contentContainerStyle={styles.itemRowContent}
                                >
                                    <View style={styles.itemRow}>
                                        <View style={styles.productInfo}>
                                            <Text style={styles.itemName}>{item.name}</Text>
                                            <Text style={styles.itemDetails}>
                                                {item.category} • {item.unit}
                                            </Text>
                                            {item.notes && (
                                                <Text style={styles.itemNotes}>📝 {item.notes}</Text>
                                            )}
                                            {cheapestStore && cheapestPrice > 0 && (
                                                <Text style={styles.cheapestInfo}>
                                                    💰 Najtaniej: {cheapestStore} -
                                                    {(cheapestPrice * item.quantity).toFixed(2)} zł
                                                </Text>
                                            )}
                                        </View>

                                        {stores.map(store => {
                                            const price = prices[store] || 0;
                                            const isCheapest = cheapestStore === store && cheapestPrice > 0;

                                            return (
                                                <View key={store} style={styles.priceInputContainer}>
                                                    <TextInput
                                                        style={[
                                                            styles.priceInput,
                                                            isCheapest && styles.cheapestPriceInput
                                                        ]}
                                                        value={price > 0 ? price.toFixed(2) : ''}
                                                        placeholder="0.00"
                                                        keyboardType="decimal-pad"
                                                        onChangeText={(text) => updatePrice(itemId, store, text)}
                                                    />
                                                    <Text style={styles.priceUnit}>zł</Text>
                                                    {isCheapest && (
                                                        <Icon name="star" size={12} color="#f39c12" style={styles.starIcon} />
                                                    )}
                                                </View>
                                            );
                                        })}

                                        <View style={styles.itemActions}>
                                            <View style={styles.quantityContainer}>
                                                <TouchableOpacity
                                                    style={styles.quantityButton}
                                                    onPress={() => updateQuantity(itemId, Math.max(1, item.quantity - 1))}
                                                >
                                                    <Icon name="remove" size={16} color="#3498db" />
                                                </TouchableOpacity>
                                                <Text style={styles.quantityText}>{item.quantity}</Text>
                                                <TouchableOpacity
                                                    style={styles.quantityButton}
                                                    onPress={() => updateQuantity(itemId, item.quantity + 1)}
                                                >
                                                    <Icon name="add" size={16} color="#3498db" />
                                                </TouchableOpacity>
                                            </View>

                                            <TouchableOpacity
                                                style={styles.deleteButton}
                                                onPress={() => removeItem(itemId)}
                                            >
                                                <Icon name="delete" size={18} color="#e74c3c" />
                                                <Text style={styles.deleteButtonText}>Usuń</Text>
                                            </TouchableOpacity>
                                        </View>
                                    </View>
                                </ScrollView>
                            </View>
                        );
                    })
                )}
            </ScrollView>

            {/* PODSUMOWANIE */}
            {items.length > 0 && (
                <View style={styles.summaryContainer}>
                    <Text style={styles.summaryTitle}>🎯 Podsumowanie</Text>
                    {bestStore && bestPrice < Infinity ? (
                        <>
                            <Text style={styles.bestStoreText}>
                                Najlepszy sklep: <Text style={styles.bestStoreName}>{bestStore}</Text>
                            </Text>
                            <Text style={styles.bestPriceText}>
                                Całkowity koszt: <Text style={styles.bestPriceValue}>{bestPrice.toFixed(2)} zł</Text>
                            </Text>
                            <Text style={styles.infoText}>
                                💡 Ceny są automatycznie zapisywane po wprowadzeniu
                            </Text>
                        </>
                    ) : (
                        <Text style={styles.noPricesText}>
                            📝 Wprowadź ceny produktów, aby zobaczyć gdzie kupić najtaniej
                        </Text>
                    )}
                </View>
            )}

            {/* MODAL DODAWANIA PRODUKTU */}
            <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible}
                onRequestClose={() => setModalVisible(false)}
            >
                <View style={styles.modalContainer}>
                    <View style={styles.modalContent}>
                        <View style={styles.modalHeader}>
                            <Text style={styles.modalTitle}>Dodaj nowy produkt</Text>
                            <TouchableOpacity onPress={() => setModalVisible(false)}>
                                <Icon name="close" size={24} color="#7f8c8d" />
                            </TouchableOpacity>
                        </View>

                        <ScrollView>
                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Nazwa produktu *</Text>
                                <TextInput
                                    style={styles.input}
                                    placeholder="np. Mleko, Chleb, Jajka"
                                    value={newItem.name}
                                    onChangeText={(text) => setNewItem({...newItem, name: text})}
                                />
                            </View>

                            <View style={styles.inputRow}>
                                <View style={[styles.inputGroup, { flex: 1, marginRight: 10 }]}>
                                    <Text style={styles.inputLabel}>Kategoria</Text>
                                    <View style={styles.categoryButtons}>
                                        {['Nabiał', 'Pieczywo', 'Warzywa', 'Owoce', 'Mięso', 'Inne'].map(cat => (
                                            <TouchableOpacity
                                                key={cat}
                                                style={[
                                                    styles.categoryButton,
                                                    newItem.category === cat && styles.categoryButtonActive
                                                ]}
                                                onPress={() => setNewItem({...newItem, category: cat})}
                                            >
                                                <Text style={[
                                                    styles.categoryButtonText,
                                                    newItem.category === cat && styles.categoryButtonTextActive
                                                ]}>
                                                    {cat}
                                                </Text>
                                            </TouchableOpacity>
                                        ))}
                                    </View>
                                </View>

                                <View style={[styles.inputGroup, { flex: 1 }]}>
                                    <Text style={styles.inputLabel}>Ilość</Text>
                                    <View style={styles.modalQuantityContainer}>
                                        <TouchableOpacity
                                            style={styles.modalQuantityButton}
                                            onPress={() => setNewItem({...newItem, quantity: Math.max(1, newItem.quantity - 1)})}
                                        >
                                            <Icon name="remove" size={20} color="#3498db" />
                                        </TouchableOpacity>
                                        <Text style={styles.modalQuantityText}>{newItem.quantity}</Text>
                                        <TouchableOpacity
                                            style={styles.modalQuantityButton}
                                            onPress={() => setNewItem({...newItem, quantity: newItem.quantity + 1})}
                                        >
                                            <Icon name="add" size={20} color="#3498db" />
                                        </TouchableOpacity>
                                        <TextInput
                                            style={styles.modalUnitInput}
                                            value={newItem.unit}
                                            onChangeText={(text) => setNewItem({...newItem, unit: text})}
                                            placeholder="szt"
                                        />
                                    </View>
                                </View>
                            </View>

                            <View style={styles.inputGroup}>
                                <Text style={styles.inputLabel}>Uwagi (opcjonalnie)</Text>
                                <TextInput
                                    style={[styles.input, styles.textArea]}
                                    placeholder="Dodaj notatki..."
                                    value={newItem.notes}
                                    onChangeText={(text) => setNewItem({...newItem, notes: text})}
                                    multiline
                                    numberOfLines={3}
                                />
                            </View>
                        </ScrollView>

                        <View style={styles.modalActions}>
                            <TouchableOpacity
                                style={styles.cancelButton}
                                onPress={() => setModalVisible(false)}
                            >
                                <Text style={styles.cancelButtonText}>Anuluj</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={styles.saveButtonModal}
                                onPress={addItem}
                            >
                                <Text style={styles.saveButtonTextModal}>Dodaj produkt</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8f9fa',
    },
    loadingContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    loadingText: {
        marginTop: 10,
        color: '#7f8c8d',
    },
    errorText: {
        marginTop: 10,
        color: '#e74c3c',
        fontSize: 16,
        fontWeight: '600',
    },
    backButtonLarge: {
        marginTop: 20,
        backgroundColor: '#3498db',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 8,
    },
    backButtonText: {
        color: 'white',
        fontWeight: '600',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingHorizontal: 20,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#ecf0f1',
    },
    backButton: {
        marginRight: 15,
    },
    headerInfo: {
        flex: 1,
    },
    listName: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#2c3e50',
    },
    listDescription: {
        fontSize: 14,
        color: '#7f8c8d',
        marginTop: 2,
    },
    addItemButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#3498db',
        paddingHorizontal: 15,
        paddingVertical: 8,
        borderRadius: 8,
        gap: 5,
    },
    addItemText: {
        color: 'white',
        fontSize: 14,
        fontWeight: '600',
    },
    actionButtonsContainer: {
        margin: 15,
    },
    refreshButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        borderWidth: 1,
        borderColor: '#3498db',
        padding: 15,
        borderRadius: 10,
        gap: 10,
    },
    refreshButtonText: {
        color: '#3498db',
        fontSize: 16,
        fontWeight: '600',
    },
    statsContainer: {
        flexDirection: 'row',
        backgroundColor: 'white',
        marginHorizontal: 15,
        marginBottom: 15,
        padding: 15,
        borderRadius: 12,
        justifyContent: 'space-around',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
        elevation: 2,
    },
    stat: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: 8,
    },
    statText: {
        fontSize: 14,
        color: '#2c3e50',
        fontWeight: '600',
    },
    storesHeaderContainer: {
        backgroundColor: 'white',
        paddingVertical: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ecf0f1',
        maxHeight: 70,
    },
    storesHeaderContent: {
        minWidth: 800,
    },
    storePriceHeader: {
        flexDirection: 'row',
        paddingHorizontal: 15,
        minWidth: 800,
    },
    productHeader: {
        width: 200,
        justifyContent: 'center',
    },
    productHeaderText: {
        fontSize: 12,
        fontWeight: '600',
        color: '#7f8c8d',
        textTransform: 'uppercase',
    },
    storeHeader: {
        width: 120,
        alignItems: 'center',
        marginHorizontal: 5,
    },
    storeHeaderText: {
        fontSize: 12,
        fontWeight: '600',
        color: '#7f8c8d',
        textTransform: 'uppercase',
        marginBottom: 5,
    },
    storeTotal: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#2c3e50',
    },
    actionsHeader: {
        width: 80,
        justifyContent: 'center',
        alignItems: 'center',
    },
    actionsHeaderText: {
        fontSize: 12,
        fontWeight: '600',
        color: '#7f8c8d',
        textTransform: 'uppercase',
    },
    itemsContainer: {
        flex: 1,
        padding: 15,
    },
    emptyItems: {
        alignItems: 'center',
        paddingVertical: 50,
    },
    emptyItemsText: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginTop: 20,
        marginBottom: 10,
    },
    emptyItemsSubtext: {
        fontSize: 14,
        color: '#7f8c8d',
        textAlign: 'center',
        marginBottom: 20,
    },
    addFirstButton: {
        backgroundColor: '#3498db',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 8,
    },
    addFirstButtonText: {
        color: 'white',
        fontWeight: '600',
        fontSize: 16,
    },
    itemCard: {
        backgroundColor: 'white',
        borderRadius: 12,
        marginBottom: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 3,
        elevation: 2,
        overflow: 'hidden',
    },
    itemRowContent: {
        minWidth: 800,
    },
    itemRow: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 15,
    },
    productInfo: {
        width: 200,
    },
    itemName: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 4,
    },
    itemDetails: {
        fontSize: 12,
        color: '#7f8c8d',
        marginBottom: 4,
    },
    itemNotes: {
        fontSize: 11,
        color: '#f39c12',
        fontStyle: 'italic',
        marginBottom: 4,
    },
    cheapestInfo: {
        fontSize: 11,
        color: '#2ecc71',
        fontWeight: '600',
    },
    priceInputContainer: {
        width: 120,
        alignItems: 'center',
        marginHorizontal: 5,
        position: 'relative',
    },
    priceInput: {
        width: '100%',
        backgroundColor: '#f8f9fa',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 6,
        paddingHorizontal: 8,
        paddingVertical: 6,
        fontSize: 14,
        textAlign: 'center',
    },
    cheapestPriceInput: {
        borderColor: '#2ecc71',
        backgroundColor: '#e8f6f3',
    },
    priceUnit: {
        fontSize: 12,
        color: '#7f8c8d',
        marginTop: 4,
    },
    starIcon: {
        position: 'absolute',
        top: -5,
        right: -5,
    },
    itemActions: {
        width: 80,
        alignItems: 'center',
        gap: 10,
    },
    quantityContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        borderRadius: 6,
        borderWidth: 1,
        borderColor: '#ddd',
        padding: 4,
    },
    quantityButton: {
        paddingHorizontal: 8,
        paddingVertical: 4,
    },
    quantityText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#2c3e50',
        marginHorizontal: 8,
    },
    deleteButton: {
        alignItems: 'center',
    },
    deleteButtonText: {
        fontSize: 10,
        color: '#e74c3c',
        marginTop: 2,
    },
    summaryContainer: {
        backgroundColor: 'white',
        padding: 20,
        borderTopWidth: 1,
        borderTopColor: '#ecf0f1',
    },
    summaryTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginBottom: 15,
    },
    bestStoreText: {
        fontSize: 16,
        color: '#2c3e50',
        marginBottom: 5,
    },
    bestStoreName: {
        fontWeight: 'bold',
        color: '#2ecc71',
    },
    bestPriceText: {
        fontSize: 16,
        color: '#2c3e50',
        marginBottom: 10,
    },
    bestPriceValue: {
        fontWeight: 'bold',
        color: '#2ecc71',
    },
    infoText: {
        fontSize: 12,
        color: '#7f8c8d',
        fontStyle: 'italic',
        marginTop: 5,
    },
    noPricesText: {
        fontSize: 14,
        color: '#f39c12',
        textAlign: 'center',
        fontStyle: 'italic',
        paddingVertical: 10,
    },
    modalContainer: {
        flex: 1,
        justifyContent: 'flex-end',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
        backgroundColor: 'white',
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        padding: 20,
        maxHeight: '80%',
    },
    modalHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 20,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#2c3e50',
    },
    inputGroup: {
        marginBottom: 15,
    },
    inputLabel: {
        fontSize: 14,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 8,
    },
    input: {
        backgroundColor: '#f8f9fa',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 10,
        padding: 12,
        fontSize: 16,
    },
    textArea: {
        height: 80,
        textAlignVertical: 'top',
    },
    inputRow: {
        flexDirection: 'row',
    },
    categoryButtons: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
    },
    categoryButton: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        backgroundColor: '#f8f9fa',
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#ddd',
    },
    categoryButtonActive: {
        backgroundColor: '#3498db',
        borderColor: '#3498db',
    },
    categoryButtonText: {
        fontSize: 12,
        color: '#7f8c8d',
    },
    categoryButtonTextActive: {
        color: 'white',
        fontWeight: '600',
    },
    modalQuantityContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#f8f9fa',
        borderRadius: 10,
        borderWidth: 1,
        borderColor: '#ddd',
        padding: 5,
    },
    modalQuantityButton: {
        paddingHorizontal: 10,
        paddingVertical: 5,
    },
    modalQuantityText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2c3e50',
        marginHorizontal: 10,
    },
    modalUnitInput: {
        flex: 1,
        fontSize: 14,
        color: '#2c3e50',
        paddingHorizontal: 8,
    },
    modalActions: {
        flexDirection: 'row',
        gap: 10,
        marginTop: 20,
    },
    cancelButton: {
        flex: 1,
        alignItems: 'center',
        padding: 15,
        backgroundColor: '#f8f9fa',
        borderRadius: 10,
    },
    cancelButtonText: {
        color: '#7f8c8d',
        fontSize: 16,
        fontWeight: '600',
    },
    saveButtonModal: {
        flex: 1,
        alignItems: 'center',
        padding: 15,
        backgroundColor: '#3498db',
        borderRadius: 10,
    },
    saveButtonTextModal: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
    },
});