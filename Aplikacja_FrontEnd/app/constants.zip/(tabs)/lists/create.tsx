import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    ScrollView,
    Alert,
    ActivityIndicator
} from 'react-native';
import { router } from 'expo-router';
import Icon from 'react-native-vector-icons/MaterialIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';

import Config from '../../constants/Config';
const API_BASE_URL = Config.API_BASE_URL;

export default function CreateListScreen() {
    const [listName, setListName] = useState('');
    const [description, setDescription] = useState('');
    const [loading, setLoading] = useState(false);

    const handleCreateList = async () => {
        if (!listName.trim()) {
            Alert.alert('Błąd', 'Wprowadź nazwę listy');
            return;
        }

        try {
            setLoading(true);

            // Pobierz dane użytkownika z AsyncStorage
            const email = await AsyncStorage.getItem('email');
            const username = await AsyncStorage.getItem('username');

            // Tymczasowy userId - w prawdziwej aplikacji użyj ID z tokena
            const userId = email || 'demo-user';

            // Przygotuj dane do wysłania
            const listData = {
                name: listName.trim(),
                description: description.trim() || null
            };

            console.log('Wysyłanie danych:', { userId, ...listData });

            // Wyślij żądanie do backendu
            const response = await fetch(`${API_BASE_URL}/shopping/lists?userId=${userId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify(listData),
            });

            console.log('Status odpowiedzi:', response.status);

            if (response.ok) {
                const createdList = await response.json();
                console.log('Utworzona lista:', createdList);

                Alert.alert(
                    'Sukces!',
                    `Lista "${listName}" została utworzona`,
                    [
                        {
                            text: 'OK',
                            onPress: () => {
                                // Przekaż dane przez router
                                router.replace({
                                    pathname: '/(tabs)/lists/[id]',
                                    params: { id: createdList.id }
                                });
                            }
                        }
                    ]
                );
            } else {
                const errorText = await response.text();
                console.error('Błąd odpowiedzi:', errorText);

                let errorMessage = 'Nie udało się utworzyć listy';
                try {
                    const errorData = JSON.parse(errorText);
                    errorMessage = errorData.message || errorMessage;
                } catch (e) {
                    // Jeśli nie można sparsować JSON, użyj tekstu
                    if (errorText.includes('already exists')) {
                        errorMessage = 'Lista o tej nazwie już istnieje';
                    }
                }

                Alert.alert('Błąd', errorMessage);
            }
        } catch (error: any) {
            console.error('Błąd tworzenia listy:', error);

            // Szczegółowe informacje o błędzie
            let errorMessage = 'Nie udało się połączyć z serwerem';
            if (error.message) {
                errorMessage += `: ${error.message}`;
            }
            if (error.code) {
                errorMessage += ` (kod: ${error.code})`;
            }

            Alert.alert('Błąd połączenia', errorMessage);

            // Tymczasowo symuluj sukces dla demo
            if (__DEV__) {
                simulateDemoSuccess();
            }
        } finally {
            setLoading(false);
        }
    };

    const simulateDemoSuccess = () => {
        Alert.alert(
            'Demo: Sukces!',
            `Lista "${listName}" została utworzona (tryb demo)`,
            [{
                text: 'OK',
                onPress: () => {
                    // Przekieruj do szczegółów z przykładowym ID
                    router.replace({
                        pathname: '/(tabs)/lists/[id]',
                        params: {
                            id: `demo-${Date.now()}`,
                            demo: 'true',
                            listName: listName
                        }
                    });
                }
            }]
        );
    };

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                    <Icon name="arrow-back" size={24} color="#2c3e50" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Nowa lista zakupów</Text>
            </View>

            <View style={styles.form}>
                <View style={styles.inputContainer}>
                    <Text style={styles.label}>Nazwa listy *</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="np. Zakupy na weekend"
                        value={listName}
                        onChangeText={setListName}
                        maxLength={50}
                        editable={!loading}
                    />
                    <Text style={styles.charCount}>{listName.length}/50</Text>
                </View>

                <View style={styles.inputContainer}>
                    <Text style={styles.label}>Opis (opcjonalnie)</Text>
                    <TextInput
                        style={[styles.input, styles.textArea]}
                        placeholder="Dodaj opis listy..."
                        value={description}
                        onChangeText={setDescription}
                        multiline
                        numberOfLines={4}
                        maxLength={200}
                        editable={!loading}
                    />
                    <Text style={styles.charCount}>{description.length}/200</Text>
                </View>

                <TouchableOpacity
                    style={[styles.createButton, loading && styles.buttonDisabled]}
                    onPress={handleCreateList}
                    disabled={loading}
                >
                    {loading ? (
                        <ActivityIndicator color="white" />
                    ) : (
                        <>
                            <Icon name="check" size={20} color="white" />
                            <Text style={styles.createButtonText}>Utwórz listę</Text>
                        </>
                    )}
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.cancelButton}
                    onPress={() => router.back()}
                    disabled={loading}
                >
                    <Text style={styles.cancelButtonText}>Anuluj</Text>
                </TouchableOpacity>
            </View>

            <View style={styles.debugInfo}>
                <Text style={styles.debugTitle}>ℹ️ Informacje debug:</Text>
                <Text style={styles.debugText}>• Backend URL: {API_BASE_URL}</Text>
                <Text style={styles.debugText}>• Metoda: POST /api/shopping/lists</Text>
                <Text style={styles.debugText}>• Sprawdź konsolę przeglądarki/terminal</Text>
            </View>

            <View style={styles.tipsContainer}>
                <Text style={styles.tipsTitle}>💡 Porady:</Text>
                <View style={styles.tipItem}>
                    <Icon name="check-circle" size={16} color="#2ecc71" />
                    <Text style={styles.tipText}>Nadaj konkretną nazwę</Text>
                </View>
                <View style={styles.tipItem}>
                    <Icon name="check-circle" size={16} color="#2ecc71" />
                    <Text style={styles.tipText}>Możesz dodać produkty po utworzeniu</Text>
                </View>
                <View style={styles.tipItem}>
                    <Icon name="check-circle" size={16} color="#2ecc71" />
                    <Text style={styles.tipText}>Zapisywane w bazie danych</Text>
                </View>
            </View>
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8f9fa',
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'white',
        paddingHorizontal: 20,
        paddingVertical: 15,
        borderBottomWidth: 1,
        borderBottomColor: '#ecf0f1',
    },
    backButton: {
        marginRight: 15,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#2c3e50',
    },
    form: {
        padding: 20,
    },
    inputContainer: {
        marginBottom: 20,
    },
    label: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 8,
    },
    input: {
        backgroundColor: 'white',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 10,
        padding: 15,
        fontSize: 16,
    },
    textArea: {
        height: 100,
        textAlignVertical: 'top',
    },
    charCount: {
        textAlign: 'right',
        fontSize: 12,
        color: '#95a5a6',
        marginTop: 5,
    },
    createButton: {
        flexDirection: 'row',
        backgroundColor: '#3498db',
        borderRadius: 10,
        padding: 18,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 10,
        gap: 10,
    },
    buttonDisabled: {
        backgroundColor: '#bdc3c7',
    },
    createButtonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
    },
    cancelButton: {
        alignItems: 'center',
        padding: 15,
        marginTop: 10,
    },
    cancelButtonText: {
        color: '#e74c3c',
        fontSize: 16,
        fontWeight: '600',
    },
    debugInfo: {
        backgroundColor: '#fff8e1',
        margin: 20,
        padding: 15,
        borderRadius: 12,
        borderLeftWidth: 4,
        borderLeftColor: '#f39c12',
    },
    debugTitle: {
        fontSize: 14,
        fontWeight: 'bold',
        color: '#d35400',
        marginBottom: 8,
    },
    debugText: {
        fontSize: 12,
        color: '#e67e22',
        marginBottom: 4,
    },
    tipsContainer: {
        backgroundColor: '#e8f4fc',
        margin: 20,
        padding: 20,
        borderRadius: 12,
    },
    tipsTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginBottom: 15,
    },
    tipItem: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        marginBottom: 10,
        gap: 10,
    },
    tipText: {
        flex: 1,
        fontSize: 14,
        color: '#3498db',
        lineHeight: 20,
    },
});