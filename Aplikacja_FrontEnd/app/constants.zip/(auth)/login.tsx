import React, { useState } from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    Alert,
    ScrollView,
    ActivityIndicator,
    KeyboardAvoidingView,
    Platform
} from 'react-native';
import { Link, router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/MaterialIcons';

import Config from '../constants/Config';
const API_BASE_URL = Config.API_BASE_URL;

export default function LoginScreen() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const handleLogin = async () => {
        if (!email.trim() || !password) {
            Alert.alert('Błąd', 'Wprowadź email i hasło');
            return;
        }

        setLoading(true);
        try {
            const response = await fetch(`${API_BASE_URL}/auth/login`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, password }),
            });

            const data = await response.json();

            if (response.ok) {
                await AsyncStorage.setItem('token', data.token || 'dummy-token');
                await AsyncStorage.setItem('username', data.username || 'Użytkownik');
                await AsyncStorage.setItem('email', data.email);

                Alert.alert('Sukces!', 'Zalogowano pomyślnie!');
                router.replace('/(tabs)');
            } else {
                Alert.alert('Błąd logowania', data.message || 'Nieprawidłowe dane');
            }
        } catch (error) {
            console.error('Login error:', error);
            Alert.alert('Błąd połączenia', 'Nie udało się połączyć z serwerem');

            await AsyncStorage.setItem('token', 'offline-token');
            await AsyncStorage.setItem('username', 'Użytkownik Offline');
            await AsyncStorage.setItem('email', email);
            router.replace('/(tabs)');
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView
            style={styles.container}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        >
            <ScrollView contentContainerStyle={styles.scrollContainer}>
                <View style={styles.header}>
                    <Icon name="shopping-cart" size={60} color="#3498db" />
                    <Text style={styles.title}>Asystent Zakupów</Text>
                    <Text style={styles.subtitle}>Zaloguj się do aplikacji</Text>
                </View>

                <View style={styles.form}>
                    <Text style={styles.label}>Email</Text>
                    <View style={styles.inputContainer}>
                        <Icon name="email" size={20} color="#95a5a6" style={styles.inputIcon} />
                        <TextInput
                            style={styles.input}
                            placeholder="twoj@email.com"
                            value={email}
                            onChangeText={setEmail}
                            keyboardType="email-address"
                            autoCapitalize="none"
                            editable={!loading}
                        />
                    </View>

                    <Text style={styles.label}>Hasło</Text>
                    <View style={styles.inputContainer}>
                        <Icon name="lock" size={20} color="#95a5a6" style={styles.inputIcon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Twoje hasło"
                            value={password}
                            onChangeText={setPassword}
                            secureTextEntry={!showPassword}
                            editable={!loading}
                        />
                        <TouchableOpacity
                            onPress={() => setShowPassword(!showPassword)}
                            style={styles.eyeIcon}
                        >
                            <Icon
                                name={showPassword ? "visibility-off" : "visibility"}
                                size={20}
                                color="#95a5a6"
                            />
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity
                        style={[styles.button, loading && styles.buttonDisabled]}
                        onPress={handleLogin}
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator color="white" />
                        ) : (
                            <>
                                <Icon name="login" size={20} color="white" />
                                <Text style={styles.buttonText}>Zaloguj się</Text>
                            </>
                        )}
                    </TouchableOpacity>

                    <View style={styles.divider}>
                        <View style={styles.dividerLine} />
                        <Text style={styles.dividerText}>lub</Text>
                        <View style={styles.dividerLine} />
                    </View>

                    <Link href="/(auth)/register" asChild>
                        <TouchableOpacity style={styles.secondaryButton}>
                            <Icon name="person-add" size={20} color="#3498db" />
                            <Text style={styles.secondaryButtonText}>Utwórz nowe konto</Text>
                        </TouchableOpacity>
                    </Link>

                    <View style={styles.footer}>
                        <Text style={styles.footerText}>Wersja 1.0.0</Text>
                    </View>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#f8f9fa',
    },
    scrollContainer: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 20,
    },
    header: {
        alignItems: 'center',
        marginBottom: 40,
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#2c3e50',
        marginTop: 15,
        marginBottom: 5,
    },
    subtitle: {
        fontSize: 16,
        color: '#7f8c8d',
        textAlign: 'center',
    },
    form: {
        backgroundColor: 'white',
        borderRadius: 16,
        padding: 25,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
        elevation: 5,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#2c3e50',
        marginBottom: 8,
        marginLeft: 5,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#ddd',
        borderRadius: 10,
        marginBottom: 20,
        backgroundColor: '#f8f9fa',
    },
    inputIcon: {
        marginLeft: 15,
    },
    input: {
        flex: 1,
        padding: 15,
        fontSize: 16,
        color: '#2c3e50',
    },
    eyeIcon: {
        padding: 15,
    },
    button: {
        flexDirection: 'row',
        backgroundColor: '#3498db',
        borderRadius: 10,
        padding: 18,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 10,
        gap: 10,
    },
    buttonDisabled: {
        backgroundColor: '#bdc3c7',
    },
    buttonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
    },
    divider: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 25,
    },
    dividerLine: {
        flex: 1,
        height: 1,
        backgroundColor: '#ecf0f1',
    },
    dividerText: {
        paddingHorizontal: 15,
        color: '#95a5a6',
        fontSize: 14,
    },
    secondaryButton: {
        flexDirection: 'row',
        borderWidth: 2,
        borderColor: '#3498db',
        borderRadius: 10,
        padding: 16,
        alignItems: 'center',
        justifyContent: 'center',
        gap: 10,
    },
    secondaryButtonText: {
        color: '#3498db',
        fontSize: 16,
        fontWeight: '600',
    },
    footer: {
        marginTop: 30,
        alignItems: 'center',
    },
    footerText: {
        color: '#bdc3c7',
        fontSize: 12,
    },
});